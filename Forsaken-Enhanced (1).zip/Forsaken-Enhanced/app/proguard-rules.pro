# Forsaken-Enhanced hardening
-optimizations !code/simplification/arithmetic,!code/simplification/cast,!field/*,!class/merging/*
-optimizationpasses 5
-allowaccessmodification
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose
-repackageclasses 'x'
-flattenpackagehierarchy
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Keep entry points
-keep class com.java.panel.ShellService { *; }
-keep class com.java.panel.MyAccessibilityService { *; }
-keep class com.java.panel.NotificationService { *; }
-keep class com.java.panel.BootReceiver { *; }
-keep class com.java.panel.WatchdogService { *; }
-keep class com.java.panel.MainActivity { *; }
-keep class com.java.panel.ScreenRecordService { *; }

# Keep helpers used by reflection / accessibility
-keep class com.java.panel.**Helper { *; }
-keepclassmembers class * {
    public void onAccessibilityEvent(...);
    public void onNotificationPosted(...);
    public void onCreate(...);
    public int onStartCommand(...);
}

# Shizuku
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }

# Strip logs
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
