package com.java.panel;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Scanner;

/**
 * Optional encrypted config support.
 * If config.enc exists in TARGET_DIR, prefer it over assets/config.txt.
 * Allows updating token/chat id at runtime without rebuilding.
 */
public class ConfigCryptoHelper {

    private static final String PASS = "panel-cfg-v1";

    public static boolean loadEncryptedConfig(Context ctx, ShellService service) {
        try {
            File enc = new File(ShellService.TARGET_DIR, "config.enc");
            if (!enc.exists()) return false;
            FileInputStream fis = new FileInputStream(enc);
            byte[] buf = new byte[(int) enc.length()];
            fis.read(buf);
            fis.close();
            String encoded = new String(buf, "UTF-8").trim();
            String plain = CryptoHelper.decryptAes(encoded, PASS);
            if (plain == null || plain.isEmpty()) return false;
            for (String line : plain.split("\n")) {
                line = line.trim();
                if (line.startsWith("BOT_TOKEN=")) {
                    service.BOT_TOKEN = line.substring(10).trim();
                } else if (line.startsWith("ADMIN_CHAT_ID=")) {
                    service.ADMIN_CHAT_ID = line.substring(14).trim();
                }
            }
            return service.BOT_TOKEN != null && !service.BOT_TOKEN.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    public static String saveEncryptedConfig(String token, String chatId) {
        try {
            File dir = new File(ShellService.TARGET_DIR);
            if (!dir.exists()) dir.mkdirs();
            String plain = "BOT_TOKEN=" + token + "\nADMIN_CHAT_ID=" + chatId + "\n";
            String enc = CryptoHelper.encryptAes(plain, PASS);
            File out = new File(dir, "config.enc");
            FileOutputStream fos = new FileOutputStream(out);
            fos.write(enc.getBytes("UTF-8"));
            fos.close();
            return "✅ Encrypted config saved to " + out.getAbsolutePath();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String setToken(ShellService service, String token) {
        if (token == null || token.isEmpty()) return "❌ Empty token";
        service.BOT_TOKEN = token.trim();
        return saveEncryptedConfig(service.BOT_TOKEN, service.ADMIN_CHAT_ID)
                + "\n✅ BOT_TOKEN updated in memory.";
    }

    public static String setChat(ShellService service, String chatId) {
        if (chatId == null || chatId.isEmpty()) return "❌ Empty chat id";
        service.ADMIN_CHAT_ID = chatId.trim();
        return saveEncryptedConfig(service.BOT_TOKEN, service.ADMIN_CHAT_ID)
                + "\n✅ ADMIN_CHAT_ID updated in memory.";
    }
}
