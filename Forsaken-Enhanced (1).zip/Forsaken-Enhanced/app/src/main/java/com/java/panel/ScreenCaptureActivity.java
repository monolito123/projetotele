package com.java.panel;

import android.app.Activity;
import android.os.Bundle;

/** Placeholder activity referenced by manifest for possible MediaProjection flow. */
public class ScreenCaptureActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish();
    }
}
