package com.java.panel;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/**
 * Remote screen control via Accessibility gestures.
 * Supports tap, swipe, back, home, recents, text injection.
 * Not full VNC — command-driven remote control.
 */
public class ScreenControlHelper {

    public static String tap(int x, int y) {
        if (MyAccessibilityService.instance == null) {
            return "❌ Accessibility service not running. Enable it in Settings.";
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return "❌ Gestures require Android 7+";
        }
        try {
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 80));
            boolean ok = MyAccessibilityService.instance.dispatchGesture(builder.build(), null, null);
            return ok ? "✅ Tap at " + x + "," + y : "❌ Gesture dispatch failed";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String swipe(int x1, int y1, int x2, int y2, int durationMs) {
        if (MyAccessibilityService.instance == null) {
            return "❌ Accessibility service not running.";
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return "❌ Gestures require Android 7+";
        }
        try {
            if (durationMs < 50) durationMs = 300;
            Path path = new Path();
            path.moveTo(x1, y1);
            path.lineTo(x2, y2);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
            boolean ok = MyAccessibilityService.instance.dispatchGesture(builder.build(), null, null);
            return ok ? "✅ Swipe (" + x1 + "," + y1 + ") → (" + x2 + "," + y2 + ")" : "❌ Swipe failed";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String globalAction(String action) {
        if (MyAccessibilityService.instance == null) {
            return "❌ Accessibility service not running.";
        }
        try {
            int act;
            switch (action.toLowerCase()) {
                case "back":
                    act = AccessibilityService.GLOBAL_ACTION_BACK;
                    break;
                case "home":
                    act = AccessibilityService.GLOBAL_ACTION_HOME;
                    break;
                case "recents":
                case "recent":
                    act = AccessibilityService.GLOBAL_ACTION_RECENTS;
                    break;
                case "notifications":
                case "notif":
                    act = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS;
                    break;
                case "quicksettings":
                case "qs":
                    act = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS;
                    break;
                case "power":
                    act = AccessibilityService.GLOBAL_ACTION_POWER_DIALOG;
                    break;
                case "lock":
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        act = AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN;
                    } else {
                        return "❌ Lock requires Android 9+";
                    }
                    break;
                default:
                    return "❌ Unknown action. Use: back|home|recents|notifications|qs|power|lock";
            }
            boolean ok = MyAccessibilityService.instance.performGlobalAction(act);
            return ok ? "✅ Global action: " + action : "❌ Action failed";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String typeText(String text) {
        if (MyAccessibilityService.instance == null) {
            return "❌ Accessibility service not running.";
        }
        try {
            android.view.accessibility.AccessibilityNodeInfo focus =
                    MyAccessibilityService.instance.findFocus(
                            android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT);
            if (focus == null) {
                focus = MyAccessibilityService.instance.getRootInActiveWindow();
            }
            if (focus == null) return "❌ No focused input node";

            android.os.Bundle args = new android.os.Bundle();
            args.putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            boolean ok = focus.performAction(
                    android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            focus.recycle();
            return ok ? "✅ Text set: " + text : "❌ Could not set text (node may not support it)";
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String screenSize(android.content.Context ctx) {
        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(android.content.Context.WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            return "📐 Screen: " + dm.widthPixels + "x" + dm.heightPixels
                    + " density=" + dm.density
                    + " dpi=" + dm.densityDpi;
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }
}
