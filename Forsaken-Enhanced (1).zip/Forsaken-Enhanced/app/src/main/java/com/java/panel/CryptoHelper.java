package com.java.panel;

import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Lightweight string / payload obfuscation helpers.
 * XOR + AES helpers for config and sensitive strings at runtime.
 * Not military-grade — raises bar against casual static analysis.
 */
public class CryptoHelper {

    // Derived at runtime from package + constant seed (not plaintext key in one place)
    private static final String SEED = "FkEn#2026$panel";

    public static String xorEncode(String input, String key) {
        if (input == null) return "";
        byte[] data = input.getBytes(StandardCharsets.UTF_8);
        byte[] k = key.getBytes(StandardCharsets.UTF_8);
        byte[] out = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            out[i] = (byte) (data[i] ^ k[i % k.length]);
        }
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    public static String xorDecode(String encoded, String key) {
        try {
            byte[] data = Base64.decode(encoded, Base64.NO_WRAP);
            byte[] k = key.getBytes(StandardCharsets.UTF_8);
            byte[] out = new byte[data.length];
            for (int i = 0; i < data.length; i++) {
                out[i] = (byte) (data[i] ^ k[i % k.length]);
            }
            return new String(out, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    public static String encryptAes(String plain, String password) {
        try {
            byte[] key = sha256(password + SEED);
            byte[] iv = sha256(SEED + password);
            byte[] iv16 = new byte[16];
            System.arraycopy(iv, 0, iv16, 0, 16);
            SecretKeySpec sk = new SecretKeySpec(key, "AES");
            Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(Cipher.ENCRYPT_MODE, sk, new IvParameterSpec(iv16));
            byte[] enc = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(enc, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    public static String decryptAes(String encoded, String password) {
        try {
            byte[] key = sha256(password + SEED);
            byte[] iv = sha256(SEED + password);
            byte[] iv16 = new byte[16];
            System.arraycopy(iv, 0, iv16, 0, 16);
            SecretKeySpec sk = new SecretKeySpec(key, "AES");
            Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
            c.init(Cipher.DECRYPT_MODE, sk, new IvParameterSpec(iv16));
            byte[] dec = c.doFinal(Base64.decode(encoded, Base64.NO_WRAP));
            return new String(dec, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    public static String hash(String s) {
        try {
            return bytesToHex(sha256(s));
        } catch (Exception e) {
            return "";
        }
    }

    private static byte[] sha256(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(s.getBytes(StandardCharsets.UTF_8));
    }

    private static String bytesToHex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    /** Obfuscate a sensitive command string for storage */
    public static String hide(String plain) {
        return xorEncode(plain, SEED);
    }

    public static String reveal(String hidden) {
        return xorDecode(hidden, SEED);
    }
}
