package com.java.panel;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import androidx.core.content.ContextCompat;

/**
 * USSD / dialer helpers + basic dual-SIM awareness.
 */
public class UssdHelper {

    public static String sendUssd(Context ctx, String code) {
        try {
            if (code == null || code.isEmpty()) return "❌ Usage: /ussd *123#";
            String encoded = code.replace("#", Uri.encode("#"));
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED) {
                return "❌ CALL_PHONE permission missing.";
            }
            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + encoded));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            return "✅ USSD dialed: " + code;
        } catch (Exception e) {
            return "❌ USSD error: " + e.getMessage();
        }
    }

    public static String dial(Context ctx, String number) {
        try {
            if (number == null || number.isEmpty()) return "❌ Usage: /dial <number>";
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED) {
                return "❌ CALL_PHONE permission missing.";
            }
            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            return "✅ Calling: " + number;
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    public static String simInfo(Context ctx) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("📶 SIM / Telephony info\n");
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "❌ TelephonyManager unavailable";

            sb.append("• Network: ").append(safe(tm.getNetworkOperatorName())).append("\n");
            sb.append("• SIM operator: ").append(safe(tm.getSimOperatorName())).append("\n");
            sb.append("• SIM state: ").append(tm.getSimState()).append("\n");
            sb.append("• Phone type: ").append(tm.getPhoneType()).append("\n");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE)
                            == PackageManager.PERMISSION_GRANTED) {
                        sb.append("• Phone count: ").append(tm.getPhoneCount()).append("\n");
                    }
                } catch (Exception ignored) {}
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                try {
                    TelecomManager telecom = (TelecomManager) ctx.getSystemService(Context.TELECOM_SERVICE);
                    if (telecom != null) {
                        sb.append("• Default dialer: ").append(safe(telecom.getDefaultDialerPackage())).append("\n");
                    }
                } catch (Exception ignored) {}
            }
            return sb.toString();
        } catch (Exception e) {
            return "❌ " + e.getMessage();
        }
    }

    private static String safe(String s) {
        return s != null ? s : "n/a";
    }
}
